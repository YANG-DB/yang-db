package com.kayhut.fuse.neo4j;

/**
 * Created by Elad on 5/29/2017.
 */
public interface GraphConfig {
    String getboltUrl();
    String getUser();
    String getPwd();
}
