package com.kayhut.fuse.gta.strategy.common;

/**
 * Created by Roman on 29/05/2017.
 */
public enum EntityTranslationOptions {
    none,
    filterEntity
}
