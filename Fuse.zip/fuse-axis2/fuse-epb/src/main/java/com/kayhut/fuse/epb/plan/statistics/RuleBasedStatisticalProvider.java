package com.kayhut.fuse.epb.plan.statistics;

/**
 * Created by lior.perry on 2/18/2018.
 */
public interface RuleBasedStatisticalProvider extends StatisticsProvider {
}
