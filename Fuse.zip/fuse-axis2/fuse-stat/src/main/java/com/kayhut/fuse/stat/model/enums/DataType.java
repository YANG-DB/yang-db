package com.kayhut.fuse.stat.model.enums;

/**
 * Created by benishue on 23-May-17.
 */

public enum DataType {
    string,
    term,
    numericDouble,
    numericLong
}
