package com.kayhut.fuse.stat.model.enums;

/**
 * Created by benishue on 30-Apr-17.
 */
public enum HistogramType {
    numeric,
    string,
    manual,
    composite,
    term,
    dynamic
}
