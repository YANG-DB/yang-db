package com.kayhut.fuse.stat.model.bucket;

/**
 * Created by benishue on 22-May-17.
 */
public class Bucket {

    public Bucket() {
        //needed for Jackson
    }
}
